package com.example.smartagriculture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartAgricultureApplicationTests {

    @Test
    void contextLoads() {
    }

}